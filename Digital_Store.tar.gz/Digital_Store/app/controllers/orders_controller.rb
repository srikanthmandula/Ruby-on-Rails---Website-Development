class OrdersController < ActionController::Base

def new
@order = Order.new
@product=@product
end

def create
@order=Order.new(params[:id])
@order.save
redirect_to order_path(@order)

end

def show
end




end
