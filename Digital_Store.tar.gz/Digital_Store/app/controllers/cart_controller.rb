class CartController < ApplicationController

def add

end
def show

@product=Product.find(params[:id])
end


end
