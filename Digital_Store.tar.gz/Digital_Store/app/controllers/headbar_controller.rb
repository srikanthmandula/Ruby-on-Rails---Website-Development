class HeadbarController < ApplicationController

def aboutus

end

def careers

end

def customerservice

end

def contactus

end



end
