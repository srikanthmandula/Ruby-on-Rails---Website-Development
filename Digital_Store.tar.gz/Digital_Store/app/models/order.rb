class Order < ApplicationRecord

end
