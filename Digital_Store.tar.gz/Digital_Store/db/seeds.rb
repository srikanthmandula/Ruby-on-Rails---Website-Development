# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

require 'csv'
CSV.foreach(Rails.root.join("db/seed_file/seed_file.csv"), headers: true) do |row|
  Product.find_or_create_by(Product_Id: row[0], Product_Category: row[1], Product_Name: row[2], Price: row[3], Product_Description: row[4], Discount: row[5],Offers: row[6])
end
