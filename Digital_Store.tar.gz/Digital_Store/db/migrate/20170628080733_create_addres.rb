class CreateAddres < ActiveRecord::Migration[5.1]
  def change
    create_table :addres do |t|

t.string :Door_No
t.text :Street_Name
t.string :city
t.string :state
t.string :contact_No


	
    end
  end
end
