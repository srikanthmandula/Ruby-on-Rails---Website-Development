class CreateProducts < ActiveRecord::Migration[5.1]
  def change
    create_table :products do |t|
      t.string :Product_Id
      t.string :Product_Category
      t.string :Product_Name
      t.string :Price
      t.string :Product_Description
      t.string :Discount
      t.string :Offers

      t.timestamps
    end
  end
end
