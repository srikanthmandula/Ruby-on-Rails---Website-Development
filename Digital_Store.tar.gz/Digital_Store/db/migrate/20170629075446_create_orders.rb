class CreateOrders < ActiveRecord::Migration[5.1]
  def change
    create_table :orders do |t|

	t.string :Door_No
	t.string :Street_Name
	t.string :City
	t.string :State
	t.string :Contact_No
	t.string :Card_No
	t.string :expiry
	t.string :CVV

    end
  end
end
