# README

This application is developed using Ruby on Rails.
Versions are :
Ruby 2.4.0
Rails 5.1.1

Database : Default database that comes with Rails "Sqlite3"
Operating System :Application is develoepd in Ubuntu 16.0.4 LST

Steps to Run the Application :

1.Download the application file
2.Change Terminal to the Application directory
3.Instantiate Rails server using command : rails s
4.Open any Browser and give address as localhost:3000

Now You can see that Application is up and running.

Note:This Application is developed as part of Academic project.
In futire many more features can be added to this application. So,this website is not yet hosted.
