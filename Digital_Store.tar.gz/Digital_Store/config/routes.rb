Rails.application.routes.draw do
  devise_for :users 
  resources :products, only: [:show, :index]
  resources :cart
  resources :orders
get 'headbar/aboutus', to: 'headbar#aboutus'
get 'headbar/careers', to: 'headbar#careers'
get 'headbar/customerservice', to: 'headbar#customerservice'
get 'headbar/contactus', to: 'headbar#contactus'

  
  root "products#home"
  
  post 'cart/add', to: 'cart#add'




  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
